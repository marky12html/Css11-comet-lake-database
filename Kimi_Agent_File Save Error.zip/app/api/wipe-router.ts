import { z } from "zod";
import { sql } from "drizzle-orm";
import { createRouter, adminQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { wipeLogs, activityLogs, birthdays, pictures, concerns } from "@db/schema";

export const wipeRouter = createRouter({
  list: adminQuery.query(async () => {
    const db = getDb();
    const all = await db
      .select()
      .from(wipeLogs)
      .orderBy(sql`${wipeLogs.createdAt} DESC`);
    return all;
  }),

  create: adminQuery
    .input(
      z.object({
        username: z.string().min(1),
        status: z.string().min(1),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.insert(wipeLogs).values(input);
      return { success: true };
    }),

  wipeDatabase: adminQuery
    .input(
      z.object({
        username: z.string().min(1),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();

      // Delete all data
      await db.delete(birthdays).where(sql`1=1`);
      await db.delete(pictures).where(sql`1=1`);
      await db.delete(concerns).where(sql`1=1`);

      // Log the wipe
      await db.insert(wipeLogs).values({
        username: input.username,
        status: "Success",
      });

      await db.insert(activityLogs).values({
        action: "WIPE",
        module: "System",
        details: "Database wiped by developer",
        userName: input.username,
      });

      return { success: true };
    }),
});
