import { z } from "zod";
import { eq, and, like, sql } from "drizzle-orm";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { birthdays, activityLogs } from "@db/schema";

export const birthdayRouter = createRouter({
  list: publicQuery.query(async () => {
    const db = getDb();
    const all = await db.select().from(birthdays).orderBy(birthdays.month, birthdays.day);
    return all;
  }),

  search: publicQuery
    .input(
      z.object({
        query: z.string().optional(),
        month: z.number().int().min(0).max(11).optional(),
      })
    )
    .query(async ({ input }) => {
      const db = getDb();
      let conditions = [];

      if (input.query) {
        conditions.push(
          sql`(${birthdays.firstName} LIKE ${`%${input.query}%`} OR ${birthdays.lastName} LIKE ${`%${input.query}%`})`
        );
      }
      if (input.month !== undefined) {
        conditions.push(eq(birthdays.month, input.month));
      }

      if (conditions.length > 0) {
        const all = await db
          .select()
          .from(birthdays)
          .where(and(...conditions))
          .orderBy(birthdays.month, birthdays.day);
        return all;
      }

      const all = await db.select().from(birthdays).orderBy(birthdays.month, birthdays.day);
      return all;
    }),

  getById: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const result = await db.select().from(birthdays).where(eq(birthdays.id, input.id));
      return result[0] ?? null;
    }),

  create: publicQuery
    .input(
      z.object({
        firstName: z.string().min(1),
        lastName: z.string().min(1),
        month: z.number().int().min(0).max(11),
        day: z.number().int().min(1).max(31),
        birthYear: z.number().int().min(1900).max(2026),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const result = await db.insert(birthdays).values(input);
      await db.insert(activityLogs).values({
        action: "ADD",
        module: "Birthday",
        details: `Added birthday: ${input.firstName} ${input.lastName}`,
        userName: "Guest",
      });
      return result;
    }),

  update: publicQuery
    .input(
      z.object({
        id: z.number(),
        firstName: z.string().min(1),
        lastName: z.string().min(1),
        month: z.number().int().min(0).max(11),
        day: z.number().int().min(1).max(31),
        birthYear: z.number().int().min(1900).max(2026),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const { id, ...data } = input;
      const result = await db.update(birthdays).set(data).where(eq(birthdays.id, id));
      await db.insert(activityLogs).values({
        action: "EDIT",
        module: "Birthday",
        details: `Updated birthday: ${data.firstName} ${data.lastName}`,
        userName: "Guest",
      });
      return result;
    }),

  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const existing = await db.select().from(birthdays).where(eq(birthdays.id, input.id));
      if (existing[0]) {
        await db.insert(activityLogs).values({
          action: "DELETE",
          module: "Birthday",
          details: `Deleted birthday: ${existing[0].firstName} ${existing[0].lastName}`,
          userName: "Guest",
        });
      }
      await db.delete(birthdays).where(eq(birthdays.id, input.id));
      return { success: true };
    }),

  stats: publicQuery.query(async () => {
    const db = getDb();
    const result = await db.select({ count: sql<number>`count(*)` }).from(birthdays);
    return { total: result[0]?.count ?? 0 };
  }),
});
