import { sql } from "drizzle-orm";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { birthdays, pictures, concerns, wipeLogs } from "@db/schema";

export const statsRouter = createRouter({
  all: publicQuery.query(async () => {
    const db = getDb();

    const [birthdayResult] = await db
      .select({ count: sql<number>`count(*)` })
      .from(birthdays);
    const [pictureResult] = await db
      .select({ count: sql<number>`count(*)` })
      .from(pictures);
    const [concernResult] = await db
      .select({ count: sql<number>`count(*)` })
      .from(concerns);
    const [wipeResult] = await db
      .select({ count: sql<number>`count(*)` })
      .from(wipeLogs);

    const totalBirthdays = birthdayResult?.count ?? 0;
    const totalPictures = pictureResult?.count ?? 0;
    const totalConcerns = concernResult?.count ?? 0;
    const wipeAttempts = wipeResult?.count ?? 0;

    return {
      totalBirthdays,
      totalPictures,
      totalConcerns,
      totalRecords: totalBirthdays + totalPictures + totalConcerns,
      wipeAttempts,
    };
  }),
});
