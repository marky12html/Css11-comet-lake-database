import { authRouter } from "./auth-router";
import { birthdayRouter } from "./birthday-router";
import { pictureRouter } from "./picture-router";
import { concernRouter } from "./concern-router";
import { activityRouter } from "./activity-router";
import { wipeRouter } from "./wipe-router";
import { statsRouter } from "./stats-router";
import { createRouter, publicQuery } from "./middleware";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  birthday: birthdayRouter,
  picture: pictureRouter,
  concern: concernRouter,
  activity: activityRouter,
  wipe: wipeRouter,
  stats: statsRouter,
});

export type AppRouter = typeof appRouter;
