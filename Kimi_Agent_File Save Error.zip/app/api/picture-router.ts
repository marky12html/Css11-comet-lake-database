import { z } from "zod";
import { eq, sql } from "drizzle-orm";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { pictures, activityLogs } from "@db/schema";

export const pictureRouter = createRouter({
  list: publicQuery.query(async () => {
    const db = getDb();
    const all = await db.select().from(pictures).orderBy(sql`${pictures.createdAt} DESC`);
    return all;
  }),

  getPublic: publicQuery.query(async () => {
    const db = getDb();
    const all = await db
      .select()
      .from(pictures)
      .where(eq(pictures.isPublic, true))
      .orderBy(sql`${pictures.createdAt} DESC`);
    return all;
  }),

  search: publicQuery
    .input(z.object({ query: z.string().optional() }))
    .query(async ({ input }) => {
      const db = getDb();
      if (input.query) {
        const all = await db
          .select()
          .from(pictures)
          .where(sql`${pictures.name} LIKE ${`%${input.query}%`}`)
          .orderBy(sql`${pictures.createdAt} DESC`);
        return all;
      }
      const all = await db.select().from(pictures).orderBy(sql`${pictures.createdAt} DESC`);
      return all;
    }),

  create: publicQuery
    .input(
      z.object({
        name: z.string().min(1),
        dataUrl: z.string().min(1),
        fileType: z.string().optional(),
        fileSize: z.number().optional(),
        isPublic: z.boolean().default(true),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const result = await db.insert(pictures).values(input);
      await db.insert(activityLogs).values({
        action: "ADD",
        module: "Picture",
        details: `Uploaded picture: ${input.name}`,
        userName: "Guest",
      });
      return result;
    }),

  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const existing = await db.select().from(pictures).where(eq(pictures.id, input.id));
      if (existing[0]) {
        await db.insert(activityLogs).values({
          action: "DELETE",
          module: "Picture",
          details: `Deleted picture: ${existing[0].name}`,
          userName: "Guest",
        });
      }
      await db.delete(pictures).where(eq(pictures.id, input.id));
      return { success: true };
    }),

  stats: publicQuery.query(async () => {
    const db = getDb();
    const result = await db.select({ count: sql<number>`count(*)` }).from(pictures);
    return { total: result[0]?.count ?? 0 };
  }),
});
