import { sql } from "drizzle-orm";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { activityLogs } from "@db/schema";

export const activityRouter = createRouter({
  list: publicQuery.query(async () => {
    const db = getDb();
    const all = await db
      .select()
      .from(activityLogs)
      .orderBy(sql`${activityLogs.createdAt} DESC`)
      .limit(100);
    return all;
  }),
});
