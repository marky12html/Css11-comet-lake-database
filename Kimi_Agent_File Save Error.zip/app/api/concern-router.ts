import { z } from "zod";
import { eq, sql } from "drizzle-orm";
import { createRouter, publicQuery, adminQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { concerns, activityLogs } from "@db/schema";

export const concernRouter = createRouter({
  list: adminQuery.query(async () => {
    const db = getDb();
    const all = await db.select().from(concerns).orderBy(sql`${concerns.createdAt} DESC`);
    return all;
  }),

  search: adminQuery
    .input(z.object({ query: z.string().optional() }))
    .query(async ({ input }) => {
      const db = getDb();
      if (input.query) {
        const all = await db
          .select()
          .from(concerns)
          .where(
            sql`(${concerns.name} LIKE ${`%${input.query}%`} OR ${concerns.message} LIKE ${`%${input.query}%`})`
          )
          .orderBy(sql`${concerns.createdAt} DESC`);
        return all;
      }
      const all = await db.select().from(concerns).orderBy(sql`${concerns.createdAt} DESC`);
      return all;
    }),

  create: publicQuery
    .input(
      z.object({
        name: z.string().min(1),
        message: z.string().min(1),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const result = await db.insert(concerns).values(input);
      await db.insert(activityLogs).values({
        action: "ADD",
        module: "Concern",
        details: `Submitted concern from: ${input.name}`,
        userName: input.name,
      });
      return result;
    }),

  update: adminQuery
    .input(
      z.object({
        id: z.number(),
        name: z.string().min(1),
        message: z.string().min(1),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const { id, ...data } = input;
      await db.update(concerns).set(data).where(eq(concerns.id, id));
      await db.insert(activityLogs).values({
        action: "EDIT",
        module: "Concern",
        details: `Updated concern from: ${data.name}`,
        userName: "Developer",
      });
      return { success: true };
    }),

  delete: adminQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const existing = await db.select().from(concerns).where(eq(concerns.id, input.id));
      if (existing[0]) {
        await db.insert(activityLogs).values({
          action: "DELETE",
          module: "Concern",
          details: `Deleted concern from: ${existing[0].name}`,
          userName: "Developer",
        });
      }
      await db.delete(concerns).where(eq(concerns.id, input.id));
      return { success: true };
    }),

  stats: adminQuery.query(async () => {
    const db = getDb();
    const result = await db.select({ count: sql<number>`count(*)` }).from(concerns);
    return { total: result[0]?.count ?? 0 };
  }),
});
