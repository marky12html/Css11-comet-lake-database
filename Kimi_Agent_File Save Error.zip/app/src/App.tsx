import { Routes, Route } from 'react-router'
import { TRPCProvider } from '@/providers/trpc'
import Layout from './components/Layout'
import Home from './pages/Home'
import Birthday from './pages/Birthday'
import Pictures from './pages/Pictures'
import Concerns from './pages/Concerns'
import Developer from './pages/Developer'
import Login from './pages/Login'
import NotFound from './pages/NotFound'

export default function App() {
  return (
    <TRPCProvider>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route element={<Layout />}>
          <Route path="/" element={<Home />} />
          <Route path="/birthday" element={<Birthday />} />
          <Route path="/pictures" element={<Pictures />} />
          <Route path="/concerns" element={<Concerns />} />
          <Route path="/developer" element={<Developer />} />
          <Route path="*" element={<NotFound />} />
        </Route>
      </Routes>
    </TRPCProvider>
  )
}
