import { useState } from 'react'
import { trpc } from '@/providers/trpc'
import { useAuth } from '@/hooks/useAuth'
import { AlertTriangle, Send, Shield, Search, Pencil, Trash2 } from 'lucide-react'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'

function getInitials(name: string) {
  const parts = name.split(' ')
  return parts.length > 1 ? (parts[0][0] + parts[1][0]).toUpperCase() : name.slice(0, 2).toUpperCase()
}

function formatDateTime(date: Date | string) {
  const d = new Date(date)
  return {
    date: d.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }),
    time: d.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
  }
}

export default function Concerns() {
  const { user, isAuthenticated } = useAuth()
  const isAdmin = isAuthenticated && user?.role === 'admin'

  const utils = trpc.useUtils()
  const createConcern = trpc.concern.create.useMutation({
    onSuccess: () => {
      utils.concern.list.invalidate()
      utils.stats.all.invalidate()
    }
  })
  const { data: concernsList, isLoading } = trpc.concern.list.useQuery(undefined, {
    enabled: isAdmin,
  })
  const deleteConcern = trpc.concern.delete.useMutation({
    onSuccess: () => { utils.concern.list.invalidate(); utils.stats.all.invalidate(); }
  })

  const [showModal, setShowModal] = useState(false)
  const [searchTerm, setSearchTerm] = useState('')
  const [formData, setFormData] = useState({ name: '', message: '' })
  const [editingId, setEditingId] = useState<number | null>(null)
  const [editForm, setEditForm] = useState({ name: '', message: '' })
  const [showEditModal, setShowEditModal] = useState(false)

  const updateConcern = trpc.concern.update.useMutation({
    onSuccess: () => { utils.concern.list.invalidate(); setShowEditModal(false); }
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    createConcern.mutate(formData)
    setFormData({ name: '', message: '' })
    setShowModal(false)
  }

  const filtered = concernsList?.filter(c =>
    !searchTerm ||
    c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.message.toLowerCase().includes(searchTerm.toLowerCase())
  )

  return (
    <div className="animate-[fadeIn_0.4s_ease]">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 pb-4" style={{ borderBottom: '1px solid var(--border-glass)' }}>
        <h2 className="text-xl font-bold flex items-center gap-3">
          <AlertTriangle size={24} style={{ color: 'var(--accent-orange)' }} />
          Concern Database
        </h2>
        <div className="flex gap-3">
          {isAdmin && (
            <button onClick={() => setShowModal(true)} className="btn-primary">
              <Send size={16} /> Add Concern
            </button>
          )}
          {!isAdmin && (
            <button onClick={() => setShowModal(true)} className="btn-primary">
              <Send size={16} /> Submit Concern
            </button>
          )}
        </div>
      </div>

      {/* Public view - submit only */}
      {!isAdmin && (
        <div className="card-glass text-center py-12">
          <Shield size={48} className="mx-auto mb-4" style={{ color: 'var(--accent-orange)' }} />
          <h3 className="text-lg font-semibold mb-2">Private Concern Database</h3>
          <p className="text-sm mb-6 max-w-md mx-auto" style={{ color: 'var(--text-muted)' }}>
            Concerns are confidential. You can submit a concern, but only authorized developers can view them.
          </p>
          <button onClick={() => setShowModal(true)} className="btn-primary">
            <Send size={16} /> Submit a Concern
          </button>
        </div>
      )}

      {/* Admin view - full list */}
      {isAdmin && (
        <>
          <div className="mb-6">
            <div className="relative">
              <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2" style={{ color: 'var(--text-muted)' }} />
              <input type="text" placeholder="Search concerns..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} className="form-input pl-10" />
            </div>
          </div>

          {isLoading ? (
            <div className="text-center py-16" style={{ color: 'var(--text-muted)' }}>
              <AlertTriangle size={32} className="mx-auto mb-3 animate-spin" style={{ color: 'var(--accent-orange)' }} />
              <p>Loading concerns...</p>
            </div>
          ) : !filtered || filtered.length === 0 ? (
            <div className="text-center py-16" style={{ color: 'var(--text-muted)' }}>
              <AlertTriangle size={48} className="mx-auto mb-4 opacity-50" />
              <h4 className="text-base font-semibold mb-1" style={{ color: 'var(--text-secondary)' }}>No concerns found</h4>
              <p className="text-sm">Submit concerns to see them here</p>
            </div>
          ) : (
            <div className="flex flex-col gap-3">
              {filtered.map((c) => {
                const dt = formatDateTime(c.createdAt)
                return (
                  <div
                    key={c.id}
                    className="rounded-2xl p-5"
                    style={{ background: 'var(--bg-card)', border: '1px solid var(--border-glass)' }}
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <div
                          className="w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm text-white flex-shrink-0"
                          style={{ background: 'var(--accent-orange)' }}
                        >
                          {getInitials(c.name)}
                        </div>
                        <div>
                          <h4 className="text-sm font-semibold">{c.name}</h4>
                          <span className="text-xs" style={{ color: 'var(--text-muted)' }}>
                            {dt.date} at {dt.time}
                          </span>
                        </div>
                      </div>
                      <span
                        className="text-xs font-semibold px-3 py-1 rounded-full"
                        style={{ color: 'var(--accent-orange)', background: 'rgba(249, 115, 22, 0.1)' }}
                      >
                        Concern
                      </span>
                    </div>
                    <div className="py-3 my-3" style={{ borderTop: '1px solid var(--border-glass)', borderBottom: '1px solid var(--border-glass)' }}>
                      <p className="text-sm leading-relaxed" style={{ color: 'var(--text-secondary)' }}>{c.message}</p>
                    </div>
                    <div className="flex justify-end gap-2">
                      <button
                        onClick={() => { setEditingId(c.id); setEditForm({ name: c.name, message: c.message }); setShowEditModal(true); }}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors hover:text-white"
                        style={{ background: 'rgba(59, 130, 246, 0.1)', color: 'var(--accent-blue)' }}
                      >
                        <Pencil size={12} /> Edit
                      </button>
                      <button
                        onClick={() => { if (confirm('Delete this concern?')) deleteConcern.mutate({ id: c.id }); }}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors hover:!bg-red-500 hover:!text-white"
                        style={{ background: 'rgba(239, 68, 68, 0.1)', color: 'var(--accent-red)' }}
                      >
                        <Trash2 size={12} /> Delete
                      </button>
                    </div>
                  </div>
                )
              })}
            </div>
          )}
        </>
      )}

      {/* Submit Modal */}
      <Dialog open={showModal} onOpenChange={setShowModal}>
        <DialogContent className="glass max-w-lg" style={{ background: 'var(--bg-card)' }}>
          <DialogHeader>
            <DialogTitle className="text-lg font-bold">Submit Concern</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="flex flex-col gap-4 mt-2">
            <div>
              <label className="block mb-2 text-sm font-medium" style={{ color: 'var(--text-secondary)' }}>Name</label>
              <input required value={formData.name} onChange={e => setFormData({ ...formData, name: e.target.value })} className="form-input" placeholder="Enter your name" />
            </div>
            <div>
              <label className="block mb-2 text-sm font-medium" style={{ color: 'var(--text-secondary)' }}>Concern Message</label>
              <textarea required rows={5} value={formData.message} onChange={e => setFormData({ ...formData, message: e.target.value })} className="form-input resize-none" placeholder="Describe your concern..." />
            </div>
            <div className="flex justify-end gap-3">
              <button type="button" onClick={() => setShowModal(false)} className="btn-secondary">Cancel</button>
              <button type="submit" className="btn-primary">
                <Send size={16} /> Submit
              </button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Edit Modal */}
      <Dialog open={showEditModal} onOpenChange={setShowEditModal}>
        <DialogContent className="glass max-w-lg" style={{ background: 'var(--bg-card)' }}>
          <DialogHeader>
            <DialogTitle className="text-lg font-bold">Edit Concern</DialogTitle>
          </DialogHeader>
          <form onSubmit={(e) => { e.preventDefault(); if (editingId) updateConcern.mutate({ id: editingId, ...editForm }); }} className="flex flex-col gap-4 mt-2">
            <div>
              <label className="block mb-2 text-sm font-medium" style={{ color: 'var(--text-secondary)' }}>Name</label>
              <input required value={editForm.name} onChange={e => setEditForm({ ...editForm, name: e.target.value })} className="form-input" />
            </div>
            <div>
              <label className="block mb-2 text-sm font-medium" style={{ color: 'var(--text-secondary)' }}>Message</label>
              <textarea required rows={5} value={editForm.message} onChange={e => setEditForm({ ...editForm, message: e.target.value })} className="form-input resize-none" />
            </div>
            <div className="flex justify-end gap-3">
              <button type="button" onClick={() => setShowEditModal(false)} className="btn-secondary">Cancel</button>
              <button type="submit" className="btn-primary">Update</button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  )
}
