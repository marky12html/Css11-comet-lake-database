import { useState } from 'react'
import { trpc } from '@/providers/trpc'
import { Cake, Plus, Search, Pencil, Trash2, Download, FileSpreadsheet, FileText } from 'lucide-react'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'

function getMonthName(m: number) {
  return ['January','February','March','April','May','June','July','August','September','October','November','December'][m]
}

function calculateAge(birthYear: number, birthMonth: number, birthDay: number) {
  const today = new Date()
  let age = today.getFullYear() - birthYear
  const m = today.getMonth() - birthMonth
  if (m < 0 || (m === 0 && today.getDate() < birthDay)) age--
  return age
}

function getInitials(firstName: string, lastName: string) {
  return (firstName[0] + lastName[0]).toUpperCase()
}

function convertToCSV(data: Array<Record<string, unknown>>, fields: string[]) {
  const headers = fields.map(f => f.charAt(0).toUpperCase() + f.slice(1)).join(',')
  const rows = data.map(row =>
    fields.map(f => {
      const val = row[f]
      if (f === 'month' && typeof val === 'number') return getMonthName(val)
      return `"${String(val ?? '').replace(/"/g, '""')}"`
    }).join(',')
  )
  return [headers, ...rows].join('\n')
}

export default function Birthday() {
  const utils = trpc.useUtils()
  const { data: birthdays, isLoading } = trpc.birthday.list.useQuery()
  const createBirthday = trpc.birthday.create.useMutation({ onSuccess: () => { utils.birthday.list.invalidate(); utils.stats.all.invalidate(); } })
  const updateBirthday = trpc.birthday.update.useMutation({ onSuccess: () => { utils.birthday.list.invalidate(); utils.stats.all.invalidate(); } })
  const deleteBirthday = trpc.birthday.delete.useMutation({ onSuccess: () => { utils.birthday.list.invalidate(); utils.stats.all.invalidate(); } })

  const [searchTerm, setSearchTerm] = useState('')
  const [monthFilter, setMonthFilter] = useState<string>('all')
  const [showModal, setShowModal] = useState(false)
  const [editingId, setEditingId] = useState<number | null>(null)
  const [formData, setFormData] = useState({ firstName: '', lastName: '', month: 0, day: 1, birthYear: 2000 })
  const [exportOpen, setExportOpen] = useState(false)

  const filtered = birthdays?.filter((b) => {
    const matchSearch = !searchTerm || b.firstName.toLowerCase().includes(searchTerm.toLowerCase()) || b.lastName.toLowerCase().includes(searchTerm.toLowerCase())
    const matchMonth = monthFilter === 'all' || b.month === parseInt(monthFilter)
    return matchSearch && matchMonth
  })

  const grouped = filtered?.reduce<Record<string, typeof filtered>>((acc, b) => {
    const mn = getMonthName(b.month)
    if (!acc[mn]) acc[mn] = []
    acc[mn].push(b)
    return acc
  }, {})

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (editingId) {
      updateBirthday.mutate({ id: editingId, ...formData })
    } else {
      createBirthday.mutate(formData)
    }
    setShowModal(false)
    setEditingId(null)
    setFormData({ firstName: '', lastName: '', month: 0, day: 1, birthYear: 2000 })
  }

  const handleEdit = (b: { id: number; firstName: string; lastName: string; month: number; day: number; birthYear: number }) => {
    setEditingId(b.id)
    setFormData({ firstName: b.firstName, lastName: b.lastName, month: b.month, day: b.day, birthYear: b.birthYear })
    setShowModal(true)
  }

  const handleDelete = (id: number) => {
    if (confirm('Are you sure you want to delete this birthday?')) {
      deleteBirthday.mutate({ id })
    }
  }

  const exportData = (format: string) => {
    if (!filtered) return
    const data = filtered.map(b => ({ firstName: b.firstName, lastName: b.lastName, month: b.month, day: b.day, birthYear: b.birthYear }))
    if (format === 'csv') {
      const csv = convertToCSV(data, ['firstName', 'lastName', 'month', 'day', 'birthYear'])
      const blob = new Blob([csv], { type: 'text/csv' })
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = 'birthdays.csv'
      a.click()
    }
    setExportOpen(false)
  }

  return (
    <div className="animate-[fadeIn_0.4s_ease]">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 pb-4" style={{ borderBottom: '1px solid var(--border-glass)' }}>
        <h2 className="text-xl font-bold flex items-center gap-3">
          <Cake size={24} style={{ color: 'var(--accent-blue)' }} />
          Birthday Database
        </h2>
        <div className="flex gap-3">
          <div className="relative">
            <button onClick={() => setExportOpen(!exportOpen)} className="btn-secondary">
              <Download size={16} /> Export
            </button>
            {exportOpen && (
              <div className="absolute right-0 top-12 z-50 min-w-[160px] rounded-xl overflow-hidden" style={{ background: 'var(--bg-tertiary)', border: '1px solid var(--border-glass)', boxShadow: 'var(--shadow-lg)' }}>
                <button onClick={() => exportData('csv')} className="w-full flex items-center gap-2.5 px-4 py-3 text-sm text-left transition-colors hover:bg-white/5" style={{ color: 'var(--text-secondary)' }}>
                  <FileText size={16} /> CSV
                </button>
                <button onClick={() => exportData('csv')} className="w-full flex items-center gap-2.5 px-4 py-3 text-sm text-left transition-colors hover:bg-white/5" style={{ color: 'var(--text-secondary)' }}>
                  <FileSpreadsheet size={16} /> Excel
                </button>
              </div>
            )}
          </div>
          <button onClick={() => { setEditingId(null); setFormData({ firstName: '', lastName: '', month: 0, day: 1, birthYear: 2000 }); setShowModal(true); }} className="btn-primary">
            <Plus size={16} /> Add Birthday
          </button>
        </div>
      </div>

      {/* Search & Filter */}
      <div className="flex flex-col sm:flex-row gap-4 mb-6">
        <div className="relative flex-1">
          <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2" style={{ color: 'var(--text-muted)' }} />
          <input
            type="text"
            placeholder="Search by name..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="form-input pl-10"
          />
        </div>
        <Select value={monthFilter} onValueChange={setMonthFilter}>
          <SelectTrigger className="w-full sm:w-[180px] form-input !py-2.5">
            <SelectValue placeholder="All Months" />
          </SelectTrigger>
          <SelectContent className="rounded-xl" style={{ background: 'var(--bg-tertiary)', border: '1px solid var(--border-glass)' }}>
            <SelectItem value="all">All Months</SelectItem>
            {Array.from({ length: 12 }, (_, i) => (
              <SelectItem key={i} value={String(i)}>{getMonthName(i)}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Data */}
      {isLoading ? (
        <div className="text-center py-16" style={{ color: 'var(--text-muted)' }}>
          <Cake size={32} className="mx-auto mb-3 animate-spin" style={{ color: 'var(--accent-blue)' }} />
          <p>Loading birthdays...</p>
        </div>
      ) : !grouped || Object.keys(grouped).length === 0 ? (
        <div className="text-center py-16" style={{ color: 'var(--text-muted)' }}>
          <Cake size={48} className="mx-auto mb-4 opacity-50" />
          <h4 className="text-base font-semibold mb-1" style={{ color: 'var(--text-secondary)' }}>No birthdays found</h4>
          <p className="text-sm">Add birthdays to see them here</p>
        </div>
      ) : (
        <div className="flex flex-col gap-4">
          {Object.entries(grouped).map(([month, items]) => (
            <div
              key={month}
              className="rounded-2xl overflow-hidden"
              style={{ background: 'var(--bg-card)', border: '1px solid var(--border-glass)' }}
            >
              <div className="flex items-center gap-3 px-5 py-4" style={{ background: 'rgba(59, 130, 246, 0.08)', borderBottom: '1px solid var(--border-glass)' }}>
                <div className="w-10 h-10 rounded-xl flex items-center justify-center text-white" style={{ background: 'var(--accent-blue)' }}>
                  <Cake size={18} />
                </div>
                <h3 className="text-base font-bold">{month}</h3>
                <span className="ml-auto text-xs px-3 py-1 rounded-full" style={{ background: 'var(--bg-glass)', color: 'var(--text-muted)' }}>
                  {items.length} {items.length === 1 ? 'person' : 'people'}
                </span>
              </div>
              <div className="p-2">
                {items.map((b) => (
                  <div
                    key={b.id}
                    className="flex items-center gap-3.5 px-4 py-3.5 rounded-xl transition-colors group"
                    style={{ cursor: 'pointer' }}
                    onMouseEnter={(e) => { e.currentTarget.style.background = 'var(--bg-glass)' }}
                    onMouseLeave={(e) => { e.currentTarget.style.background = 'transparent' }}
                  >
                    <div
                      className="w-11 h-11 rounded-full flex items-center justify-center text-sm font-bold text-white flex-shrink-0"
                      style={{ background: 'linear-gradient(135deg, var(--accent-blue), var(--accent-purple))' }}
                    >
                      {getInitials(b.firstName, b.lastName)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="text-sm font-semibold">{b.firstName} {b.lastName}</h4>
                      <p className="text-xs" style={{ color: 'var(--text-muted)' }}>{getMonthName(b.month)} {b.day}, {b.birthYear}</p>
                    </div>
                    <div
                      className="text-sm font-semibold px-3 py-1 rounded-full text-sm"
                      style={{ color: 'var(--accent-blue)', background: 'rgba(59, 130, 246, 0.1)' }}
                    >
                      {calculateAge(b.birthYear, b.month, b.day)} years
                    </div>
                    <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button onClick={() => handleEdit(b)} className="w-8 h-8 rounded-full flex items-center justify-center transition-colors" style={{ background: 'var(--bg-glass)', color: 'var(--text-secondary)' }}>
                        <Pencil size={13} />
                      </button>
                      <button onClick={() => handleDelete(b.id)} className="w-8 h-8 rounded-full flex items-center justify-center transition-colors hover:!bg-red-500 hover:!text-white" style={{ background: 'var(--bg-glass)', color: 'var(--text-secondary)' }}>
                        <Trash2 size={13} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Modal */}
      <Dialog open={showModal} onOpenChange={setShowModal}>
        <DialogContent className="glass !border-[var(--border-glass)] max-w-lg" style={{ background: 'var(--bg-card)' }}>
          <DialogHeader>
            <DialogTitle className="text-lg font-bold">
              {editingId ? 'Edit Birthday' : 'Add Birthday'}
            </DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="flex flex-col gap-4 mt-2">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block mb-2 text-sm font-medium" style={{ color: 'var(--text-secondary)' }}>First Name</label>
                <input required value={formData.firstName} onChange={e => setFormData({ ...formData, firstName: e.target.value })} className="form-input" placeholder="Enter first name" />
              </div>
              <div>
                <label className="block mb-2 text-sm font-medium" style={{ color: 'var(--text-secondary)' }}>Last Name</label>
                <input required value={formData.lastName} onChange={e => setFormData({ ...formData, lastName: e.target.value })} className="form-input" placeholder="Enter last name" />
              </div>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div>
                <label className="block mb-2 text-sm font-medium" style={{ color: 'var(--text-secondary)' }}>Month</label>
                <select required value={formData.month} onChange={e => setFormData({ ...formData, month: parseInt(e.target.value) })} className="form-input">
                  {Array.from({ length: 12 }, (_, i) => (
                    <option key={i} value={i}>{getMonthName(i)}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block mb-2 text-sm font-medium" style={{ color: 'var(--text-secondary)' }}>Day</label>
                <input required type="number" min={1} max={31} value={formData.day} onChange={e => setFormData({ ...formData, day: parseInt(e.target.value) })} className="form-input" />
              </div>
              <div>
                <label className="block mb-2 text-sm font-medium" style={{ color: 'var(--text-secondary)' }}>Year</label>
                <input required type="number" min={1900} max={2026} value={formData.birthYear} onChange={e => setFormData({ ...formData, birthYear: parseInt(e.target.value) })} className="form-input" />
              </div>
            </div>
            <div className="flex justify-end gap-3 mt-2">
              <button type="button" onClick={() => setShowModal(false)} className="btn-secondary">Cancel</button>
              <button type="submit" className="btn-primary">
                {editingId ? 'Update' : 'Save'}
              </button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  )
}
