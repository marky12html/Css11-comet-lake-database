import { useNavigate } from 'react-router'
import { trpc } from '@/providers/trpc'
import { Cake, Images, AlertTriangle, Users, Calendar } from 'lucide-react'
import { useMemo } from 'react'

function calculateAge(birthYear: number, birthMonth: number, birthDay: number) {
  const today = new Date()
  let age = today.getFullYear() - birthYear
  const m = today.getMonth() - birthMonth
  if (m < 0 || (m === 0 && today.getDate() < birthDay)) age--
  return age
}

function getMonthName(m: number) {
  return ['January','February','March','April','May','June','July','August','September','October','November','December'][m]
}

function getInitials(firstName: string, lastName: string) {
  return (firstName[0] + lastName[0]).toUpperCase()
}

export default function Home() {
  const navigate = useNavigate()
  const { data: stats } = trpc.stats.all.useQuery()
  const { data: publicPics } = trpc.picture.getPublic.useQuery()
  const { data: allBirthdays } = trpc.birthday.list.useQuery()

  const upcomingBirthdays = useMemo(() => {
    if (!allBirthdays) return []
    const today = new Date()
    const currentMonth = today.getMonth()
    const currentDay = today.getDate()
    const currentYear = today.getFullYear()

    return allBirthdays
      .filter((b) => {
        const bDate = new Date(currentYear, b.month, b.day)
        const diffTime = bDate.getTime() - today.getTime()
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
        return diffDays >= 0 && diffDays <= 60
      })
      .sort((a, b) => {
        const aDate = new Date(currentYear, a.month, a.day)
        const bDate = new Date(currentYear, b.month, b.day)
        return aDate.getTime() - bDate.getTime()
      })
      .slice(0, 5)
  }, [allBirthdays])

  return (
    <div className="flex flex-col gap-6 animate-[fadeIn_0.4s_ease]">
      {/* Welcome Banner */}
      <div className="card-glass text-center py-10">
        <h2
          className="text-2xl lg:text-3xl font-extrabold mb-2"
          style={{
            background: 'linear-gradient(135deg, var(--text-primary), var(--accent-blue-light))',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            backgroundClip: 'text',
          }}
        >
          Welcome to CSS Database
        </h2>
        <p style={{ color: 'var(--text-muted)' }}>Manage birthdays, pictures, and concerns easily</p>
      </div>

      {/* Shortcut Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <ShortcutCard
          icon={<Cake size={32} />}
          label="Birthday Database"
          desc="View and manage birthdays"
          count={stats?.totalBirthdays ?? 0}
          color="var(--accent-blue)"
          onClick={() => navigate('/birthday')}
        />
        <ShortcutCard
          icon={<Images size={32} />}
          label="Picture Database"
          desc="Browse and upload pictures"
          count={stats?.totalPictures ?? 0}
          color="var(--accent-purple)"
          onClick={() => navigate('/pictures')}
        />
        <ShortcutCard
          icon={<AlertTriangle size={32} />}
          label="Submit Concern"
          desc="Send a private concern"
          count={stats?.totalConcerns ?? 0}
          color="var(--accent-orange)"
          onClick={() => navigate('/concerns')}
        />
      </div>

      {/* Public Pictures Gallery */}
      <div className="card-glass">
        <div className="flex items-center justify-between mb-5">
          <h3 className="text-base font-semibold flex items-center gap-2.5">
            <Images size={18} style={{ color: 'var(--accent-purple)' }} />
            Public Pictures
          </h3>
          <button
            onClick={() => navigate('/pictures')}
            className="text-sm font-medium transition-colors"
            style={{ color: 'var(--accent-blue)' }}
          >
            View All
          </button>
        </div>
        {publicPics && publicPics.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {publicPics.slice(0, 6).map((pic) => (
              <div
                key={pic.id}
                className="rounded-xl overflow-hidden cursor-pointer transition-transform hover:scale-[1.03]"
                style={{ aspectRatio: '1', position: 'relative' }}
                onClick={() => window.open(pic.dataUrl, '_blank')}
              >
                <img src={pic.dataUrl} alt={pic.name} className="w-full h-full object-cover" loading="lazy" />
                <div
                  className="absolute bottom-0 left-0 right-0 px-3 py-2 text-xs font-medium truncate"
                  style={{ background: 'linear-gradient(transparent, rgba(0,0,0,0.8))' }}
                >
                  {pic.name}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8" style={{ color: 'var(--text-muted)' }}>
            <Images size={32} className="mx-auto mb-3 opacity-50" />
            <p>No public pictures yet</p>
          </div>
        )}
      </div>

      {/* Upcoming Birthdays */}
      <div className="card-glass">
        <div className="flex items-center justify-between mb-5">
          <h3 className="text-base font-semibold flex items-center gap-2.5">
            <Calendar size={18} style={{ color: 'var(--accent-blue)' }} />
            Upcoming Birthdays
          </h3>
          <button
            onClick={() => navigate('/birthday')}
            className="text-sm font-medium transition-colors"
            style={{ color: 'var(--accent-blue)' }}
          >
            View All
          </button>
        </div>
        {upcomingBirthdays.length > 0 ? (
          <div className="flex flex-col gap-2.5">
            {upcomingBirthdays.map((b) => (
              <div
                key={b.id}
                className="flex items-center gap-3.5 px-4 py-3 rounded-xl transition-colors"
                style={{ background: 'var(--bg-glass)' }}
              >
                <div
                  className="w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm flex-shrink-0"
                  style={{ background: 'var(--accent-blue)', color: 'white' }}
                >
                  {getInitials(b.firstName, b.lastName)}
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="text-sm font-semibold truncate">
                    {b.firstName} {b.lastName}
                  </h4>
                  <p className="text-xs truncate" style={{ color: 'var(--text-muted)' }}>
                    {getMonthName(b.month)} {b.day}, {b.birthYear}
                  </p>
                </div>
                <div
                  className="text-xs font-semibold flex-shrink-0 px-2.5 py-1 rounded-full"
                  style={{ color: 'var(--accent-blue)', background: 'rgba(59, 130, 246, 0.1)' }}
                >
                  {getMonthName(b.month).slice(0, 3)} {b.day}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8" style={{ color: 'var(--text-muted)' }}>
            <Cake size={32} className="mx-auto mb-3 opacity-50" />
            <p>No upcoming birthdays</p>
          </div>
        )}
      </div>
    </div>
  )
}

function ShortcutCard({
  icon,
  label,
  desc,
  count,
  color,
  onClick,
}: {
  icon: React.ReactNode
  label: string
  desc: string
  count: number
  color: string
  onClick: () => void
}) {
  return (
    <div
      onClick={onClick}
      className="card-glass text-center cursor-pointer flex flex-col items-center gap-3"
      style={{ transition: 'all 0.3s ease' }}
      onMouseEnter={(e) => {
        e.currentTarget.style.borderColor = color
        e.currentTarget.style.transform = 'translateY(-4px)'
        e.currentTarget.style.boxShadow = `0 0 30px ${color}26`
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.borderColor = 'var(--border-glass)'
        e.currentTarget.style.transform = 'translateY(0)'
        e.currentTarget.style.boxShadow = 'none'
      }}
    >
      <div
        className="w-16 h-16 rounded-2xl flex items-center justify-center"
        style={{ background: `${color}26`, color }}
      >
        {icon}
      </div>
      <h3 className="text-base font-semibold">{label}</h3>
      <p className="text-sm" style={{ color: 'var(--text-muted)' }}>
        {desc}
      </p>
      <span className="text-xl font-extrabold" style={{ color: 'var(--accent-blue)' }}>
        {count}
      </span>
    </div>
  )
}
