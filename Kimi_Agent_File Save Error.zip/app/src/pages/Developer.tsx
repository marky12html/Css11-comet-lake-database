import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router'
import { trpc } from '@/providers/trpc'
import { useAuth } from '@/hooks/useAuth'
import {
  Shield,
  Cake,
  Images,
  AlertTriangle,
  Trash2,
  Radiation,
  Download,
  Pencil,
  Activity,
  History,
  Lock,
} from 'lucide-react'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'

function getMonthName(m: number) {
  return ['January','February','March','April','May','June','July','August','September','October','November','December'][m]
}

function calculateAge(birthYear: number, birthMonth: number, birthDay: number) {
  const today = new Date()
  let age = today.getFullYear() - birthYear
  const m = today.getMonth() - birthMonth
  if (m < 0 || (m === 0 && today.getDate() < birthDay)) age--
  return age
}

function formatDate(date: Date | string) {
  const d = new Date(date)
  return d.toLocaleDateString('en-US')
}

function formatTime(date: Date | string) {
  const d = new Date(date)
  return d.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })
}

const WIPE_PIN = '202627'

export default function Developer() {
  const navigate = useNavigate()
  const { user, isAuthenticated, isLoading: authLoading } = useAuth()
  const isAdmin = isAuthenticated && user?.role === 'admin'

  const { data: stats } = trpc.stats.all.useQuery(undefined, { enabled: isAdmin })
  const { data: birthdays } = trpc.birthday.list.useQuery(undefined, { enabled: isAdmin })
  const { data: concerns } = trpc.concern.list.useQuery(undefined, { enabled: isAdmin })
  const { data: activities } = trpc.activity.list.useQuery(undefined, { enabled: isAdmin })
  const { data: wipeLogs } = trpc.wipe.list.useQuery(undefined, { enabled: isAdmin })

  const utils = trpc.useUtils()
  const wipeMutation = trpc.wipe.wipeDatabase.useMutation({
    onSuccess: () => {
      utils.invalidate()
      setShowWipeModal(false)
      setWipePin('')
      setWipeError('')
    }
  })

  const [activeTab, setActiveTab] = useState('birthday-records')
  const [showWipeModal, setShowWipeModal] = useState(false)
  const [wipePin, setWipePin] = useState('')
  const [wipeError, setWipeError] = useState('')

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      // Not logged in - stay on page, show login prompt
    }
  }, [authLoading, isAuthenticated])

  // Not authenticated view
  if (!isAuthenticated) {
    return (
      <div className="flex items-center justify-center min-h-[60vh] animate-[fadeIn_0.4s_ease]">
        <div className="card-glass text-center max-w-md w-full">
          <Shield size={56} className="mx-auto mb-5" style={{ color: 'var(--accent-blue)' }} />
          <h2 className="text-xl font-bold mb-2">Developer Access</h2>
          <p className="text-sm mb-6" style={{ color: 'var(--text-muted)' }}>
            Authorized personnel only. Please login with your admin account to access the developer dashboard.
          </p>
          <button onClick={() => navigate('/login')} className="btn-primary w-full">
            <Lock size={16} /> Login with Admin Account
          </button>
        </div>
      </div>
    )
  }

  // Authenticated but not admin
  if (!isAdmin) {
    return (
      <div className="flex items-center justify-center min-h-[60vh] animate-[fadeIn_0.4s_ease]">
        <div className="card-glass text-center max-w-md w-full">
          <Shield size={56} className="mx-auto mb-5" style={{ color: 'var(--accent-red)' }} />
          <h2 className="text-xl font-bold mb-2">Access Denied</h2>
          <p className="text-sm mb-6" style={{ color: 'var(--text-muted)' }}>
            You are logged in but do not have developer privileges. Admin role required.
          </p>
        </div>
      </div>
    )
  }

  // Developer Dashboard
  const handleWipe = () => {
    if (wipePin === WIPE_PIN) {
      wipeMutation.mutate({ username: user?.name || 'Unknown' })
    } else {
      setWipeError('Invalid PIN. Wipe attempt logged.')
    }
  }

  const exportAll = () => {
    const data = {
      birthdays,
      concerns,
      activityLogs: activities,
      wipeLogs,
      backupDate: new Date().toISOString(),
    }
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `css_database_backup_${new Date().toISOString().slice(0, 10)}.json`
    a.click()
  }

  const tabs = [
    { id: 'birthday-records', label: 'Birthday Records', icon: Cake },
    { id: 'concern-records', label: 'Concern Records', icon: AlertTriangle },
    { id: 'activity-logs', label: 'Activity Logs', icon: Activity },
    { id: 'wipe-logs', label: 'Wipe Logs', icon: History },
  ]

  return (
    <div className="animate-[fadeIn_0.4s_ease]">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 pb-4" style={{ borderBottom: '1px solid var(--border-glass)' }}>
        <h2 className="text-xl font-bold flex items-center gap-3">
          <Shield size={24} style={{ color: 'var(--accent-blue)' }} />
          Developer Dashboard
        </h2>
        <button onClick={exportAll} className="btn-secondary">
          <Download size={16} /> Export All Data
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard icon={<Cake size={24} />} label="Birthday Records" value={stats?.totalBirthdays ?? 0} color="var(--accent-blue)" />
        <StatCard icon={<Images size={24} />} label="Picture Records" value={stats?.totalPictures ?? 0} color="var(--accent-purple)" />
        <StatCard icon={<AlertTriangle size={24} />} label="Concern Records" value={stats?.totalConcerns ?? 0} color="var(--accent-orange)" />
        <StatCard icon={<Trash2 size={24} />} label="Wipe Attempts" value={stats?.wipeAttempts ?? 0} color="var(--accent-red)" />
      </div>

      {/* Tabs */}
      <div className="flex gap-1 mb-5 p-1.5 rounded-2xl overflow-x-auto" style={{ background: 'var(--bg-card)', border: '1px solid var(--border-glass)' }}>
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className="flex items-center gap-2 px-5 py-3 rounded-xl font-medium text-sm whitespace-nowrap transition-all flex-1 justify-center"
            style={{
              background: activeTab === tab.id ? 'var(--accent-blue)' : 'transparent',
              color: activeTab === tab.id ? 'white' : 'var(--text-secondary)',
              boxShadow: activeTab === tab.id ? '0 4px 15px rgba(59, 130, 246, 0.3)' : 'none',
            }}
          >
            <tab.icon size={16} /> {tab.label}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      <div className="mb-8">
        {/* Birthday Records */}
        {activeTab === 'birthday-records' && (
          <div className="overflow-x-auto rounded-2xl" style={{ border: '1px solid var(--border-glass)' }}>
            <table className="w-full text-sm">
              <thead style={{ background: 'var(--bg-tertiary)' }}>
                <tr>
                  {['ID', 'First Name', 'Last Name', 'Birthday', 'Age'].map(h => (
                    <th key={h} className="px-4 py-3.5 text-left font-semibold text-xs uppercase tracking-wider" style={{ color: 'var(--text-secondary)', borderBottom: '1px solid var(--border-glass)' }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {birthdays && birthdays.length > 0 ? birthdays.map(b => (
                  <tr key={b.id} className="transition-colors hover:bg-white/5">
                    <td className="px-4 py-3.5" style={{ borderBottom: '1px solid var(--border-glass)' }}>#{b.id}</td>
                    <td className="px-4 py-3.5" style={{ borderBottom: '1px solid var(--border-glass)' }}>{b.firstName}</td>
                    <td className="px-4 py-3.5" style={{ borderBottom: '1px solid var(--border-glass)' }}>{b.lastName}</td>
                    <td className="px-4 py-3.5" style={{ borderBottom: '1px solid var(--border-glass)' }}>{getMonthName(b.month)} {b.day}, {b.birthYear}</td>
                    <td className="px-4 py-3.5" style={{ borderBottom: '1px solid var(--border-glass)' }}>{calculateAge(b.birthYear, b.month, b.day)}</td>
                  </tr>
                )) : (
                  <tr><td colSpan={5} className="text-center py-10" style={{ color: 'var(--text-muted)' }}>No records</td></tr>
                )}
              </tbody>
            </table>
          </div>
        )}

        {/* Concern Records */}
        {activeTab === 'concern-records' && (
          <div className="overflow-x-auto rounded-2xl" style={{ border: '1px solid var(--border-glass)' }}>
            <table className="w-full text-sm">
              <thead style={{ background: 'var(--bg-tertiary)' }}>
                <tr>
                  {['ID', 'Name', 'Concern', 'Date', 'Time'].map(h => (
                    <th key={h} className="px-4 py-3.5 text-left font-semibold text-xs uppercase tracking-wider" style={{ color: 'var(--text-secondary)', borderBottom: '1px solid var(--border-glass)' }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {concerns && concerns.length > 0 ? concerns.map(c => {
                  const dt = formatDate(c.createdAt)
                  const tm = formatTime(c.createdAt)
                  return (
                    <tr key={c.id} className="transition-colors hover:bg-white/5">
                      <td className="px-4 py-3.5" style={{ borderBottom: '1px solid var(--border-glass)' }}>#{c.id}</td>
                      <td className="px-4 py-3.5" style={{ borderBottom: '1px solid var(--border-glass)' }}>{c.name}</td>
                      <td className="px-4 py-3.5 max-w-xs truncate" style={{ borderBottom: '1px solid var(--border-glass)' }}>{c.message}</td>
                      <td className="px-4 py-3.5" style={{ borderBottom: '1px solid var(--border-glass)' }}>{dt}</td>
                      <td className="px-4 py-3.5" style={{ borderBottom: '1px solid var(--border-glass)' }}>{tm}</td>
                    </tr>
                  )
                }) : (
                  <tr><td colSpan={5} className="text-center py-10" style={{ color: 'var(--text-muted)' }}>No records</td></tr>
                )}
              </tbody>
            </table>
          </div>
        )}

        {/* Activity Logs */}
        {activeTab === 'activity-logs' && (
          <div className="overflow-x-auto rounded-2xl" style={{ border: '1px solid var(--border-glass)' }}>
            <table className="w-full text-sm">
              <thead style={{ background: 'var(--bg-tertiary)' }}>
                <tr>
                  {['ID', 'Action', 'User', 'Module', 'Date', 'Time'].map(h => (
                    <th key={h} className="px-4 py-3.5 text-left font-semibold text-xs uppercase tracking-wider" style={{ color: 'var(--text-secondary)', borderBottom: '1px solid var(--border-glass)' }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {activities && activities.length > 0 ? activities.map(a => (
                  <tr key={a.id} className="transition-colors hover:bg-white/5">
                    <td className="px-4 py-3.5" style={{ borderBottom: '1px solid var(--border-glass)' }}>#{a.id}</td>
                    <td className="px-4 py-3.5" style={{ borderBottom: '1px solid var(--border-glass)' }}>
                      <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold ${a.action === 'DELETE' || a.action === 'WIPE' ? 'text-red-400 bg-red-400/15' : 'text-emerald-400 bg-emerald-400/15'}`}>
                        {a.action}
                      </span>
                    </td>
                    <td className="px-4 py-3.5" style={{ borderBottom: '1px solid var(--border-glass)' }}>{a.userName || 'Guest'}</td>
                    <td className="px-4 py-3.5" style={{ borderBottom: '1px solid var(--border-glass)' }}>{a.module}</td>
                    <td className="px-4 py-3.5" style={{ borderBottom: '1px solid var(--border-glass)' }}>{formatDate(a.createdAt)}</td>
                    <td className="px-4 py-3.5" style={{ borderBottom: '1px solid var(--border-glass)' }}>{formatTime(a.createdAt)}</td>
                  </tr>
                )) : (
                  <tr><td colSpan={6} className="text-center py-10" style={{ color: 'var(--text-muted)' }}>No records</td></tr>
                )}
              </tbody>
            </table>
          </div>
        )}

        {/* Wipe Logs */}
        {activeTab === 'wipe-logs' && (
          <div className="overflow-x-auto rounded-2xl" style={{ border: '1px solid var(--border-glass)' }}>
            <table className="w-full text-sm">
              <thead style={{ background: 'var(--bg-tertiary)' }}>
                <tr>
                  {['ID', 'Username', 'Date', 'Time', 'Status'].map(h => (
                    <th key={h} className="px-4 py-3.5 text-left font-semibold text-xs uppercase tracking-wider" style={{ color: 'var(--text-secondary)', borderBottom: '1px solid var(--border-glass)' }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {wipeLogs && wipeLogs.length > 0 ? wipeLogs.map(w => (
                  <tr key={w.id} className="transition-colors hover:bg-white/5">
                    <td className="px-4 py-3.5" style={{ borderBottom: '1px solid var(--border-glass)' }}>#{w.id}</td>
                    <td className="px-4 py-3.5" style={{ borderBottom: '1px solid var(--border-glass)' }}>{w.username}</td>
                    <td className="px-4 py-3.5" style={{ borderBottom: '1px solid var(--border-glass)' }}>{formatDate(w.createdAt)}</td>
                    <td className="px-4 py-3.5" style={{ borderBottom: '1px solid var(--border-glass)' }}>{formatTime(w.createdAt)}</td>
                    <td className="px-4 py-3.5" style={{ borderBottom: '1px solid var(--border-glass)' }}>
                      <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold ${w.status === 'Success' ? 'text-emerald-400 bg-emerald-400/15' : 'text-red-400 bg-red-400/15'}`}>
                        {w.status}
                      </span>
                    </td>
                  </tr>
                )) : (
                  <tr><td colSpan={5} className="text-center py-10" style={{ color: 'var(--text-muted)' }}>No records</td></tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Danger Zone */}
      <div className="card-glass text-center mt-8" style={{ borderColor: 'rgba(239, 68, 68, 0.2)', background: 'rgba(239, 68, 68, 0.05)' }}>
        <Radiation size={48} className="mx-auto mb-3" style={{ color: 'var(--accent-red)', animation: 'pulse-icon 2s infinite' }} />
        <h3 className="text-lg font-bold mb-1 tracking-widest" style={{ color: 'var(--accent-red)' }}>DANGER ZONE</h3>
        <p className="text-sm mb-6" style={{ color: 'var(--text-muted)' }}>Destructive actions cannot be undone</p>
        <button onClick={() => setShowWipeModal(true)} className="btn-danger px-10 py-4 text-base font-bold tracking-wider" style={{ animation: 'pulse-red 2s infinite' }}>
          <Trash2 size={18} /> WIPE DATABASE
        </button>
      </div>

      {/* Wipe Modal */}
      <Dialog open={showWipeModal} onOpenChange={setShowWipeModal}>
        <DialogContent className="glass max-w-md" style={{ background: 'var(--bg-card)', borderColor: 'rgba(239, 68, 68, 0.3)' }}>
          <DialogHeader className="flex flex-col items-center text-center gap-3">
            <AlertTriangle size={48} style={{ color: 'var(--accent-red)' }} />
            <DialogTitle className="text-lg font-bold">WARNING: Database Wipe</DialogTitle>
          </DialogHeader>
          <div className="flex flex-col gap-4 mt-2">
            <div className="rounded-xl p-4" style={{ background: 'rgba(239, 68, 68, 0.1)', border: '1px solid rgba(239, 68, 68, 0.2)' }}>
              <p className="text-sm mb-2" style={{ color: 'var(--accent-red)' }}><strong>WARNING:</strong> This action will permanently delete all database records.</p>
              <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>This includes ALL birthdays, pictures, and concerns. This action cannot be undone.</p>
            </div>
            <div>
              <label className="block mb-2 text-sm font-medium" style={{ color: 'var(--text-secondary)' }}>Enter 6-digit PIN to confirm</label>
              <input
                type="password"
                maxLength={6}
                value={wipePin}
                onChange={e => setWipePin(e.target.value)}
                className="form-input text-center text-lg tracking-[0.5em]"
                placeholder="------"
              />
            </div>
            {wipeError && <p className="text-sm text-center" style={{ color: 'var(--accent-red)' }}>{wipeError}</p>}
            <div className="flex justify-end gap-3">
              <button onClick={() => { setShowWipeModal(false); setWipePin(''); setWipeError(''); }} className="btn-secondary">Cancel</button>
              <button onClick={handleWipe} className="btn-danger">
                <Trash2 size={16} /> WIPE DATABASE
              </button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}

function StatCard({ icon, label, value, color }: { icon: React.ReactNode; label: string; value: number; color: string }) {
  return (
    <div className="card-glass flex items-center gap-4 relative overflow-hidden">
      <div className="absolute -top-1/2 -right-1/2 w-full h-full pointer-events-none" style={{ background: 'radial-gradient(circle, rgba(255,255,255,0.03) 0%, transparent 70%)' }} />
      <div className="w-14 h-14 rounded-xl flex items-center justify-center text-lg flex-shrink-0" style={{ background: `${color}26`, color }}>
        {icon}
      </div>
      <div>
        <h3 className="text-2xl font-extrabold">{value}</h3>
        <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>{label}</p>
      </div>
    </div>
  )
}
