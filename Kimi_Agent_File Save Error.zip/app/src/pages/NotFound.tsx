import { Link } from 'react-router'
import { Home, AlertCircle } from 'lucide-react'

export default function NotFound() {
  return (
    <div className="flex items-center justify-center min-h-[60vh]" style={{ background: 'var(--bg-primary)' }}>
      <div className="card-glass text-center max-w-md w-full mx-4">
        <AlertCircle size={56} className="mx-auto mb-4" style={{ color: 'var(--accent-orange)' }} />
        <h1 className="text-4xl font-extrabold mb-2" style={{ background: 'linear-gradient(135deg, var(--text-primary), var(--accent-blue-light))', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text' }}>
          404
        </h1>
        <h2 className="text-lg font-semibold mb-3">Page Not Found</h2>
        <p className="text-sm mb-6" style={{ color: 'var(--text-muted)' }}>
          The page you are looking for does not exist or has been moved.
        </p>
        <Link to="/" className="btn-primary inline-flex">
          <Home size={16} /> Back to Home
        </Link>
      </div>
    </div>
  )
}
