import { useState, useRef } from 'react'
import { trpc } from '@/providers/trpc'
import { Images, CloudUpload, X, Eye, Download, Trash2 } from 'lucide-react'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'

function formatDate(dateStr: Date | string) {
  const d = new Date(dateStr)
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
}

export default function Pictures() {
  const utils = trpc.useUtils()
  const { data: pictures, isLoading } = trpc.picture.list.useQuery()
  const createPicture = trpc.picture.create.useMutation({ onSuccess: () => { utils.picture.list.invalidate(); utils.picture.getPublic.invalidate(); utils.stats.all.invalidate(); } })
  const deletePicture = trpc.picture.delete.useMutation({ onSuccess: () => { utils.picture.list.invalidate(); utils.picture.getPublic.invalidate(); utils.stats.all.invalidate(); } })

  const [searchTerm, setSearchTerm] = useState('')
  const [showModal, setShowModal] = useState(false)
  const [previewUrl, setPreviewUrl] = useState('')
  const [fileName, setFileName] = useState('')
  const [pictureName, setPictureName] = useState('')
  const [isPublic, setIsPublic] = useState(true)
  const [currentFile, setCurrentFile] = useState<File | null>(null)
  const [viewImage, setViewImage] = useState('')
  const fileInputRef = useRef<HTMLInputElement>(null)
  const [isDragOver, setIsDragOver] = useState(false)

  const filtered = pictures?.filter(p =>
    !searchTerm || p.name.toLowerCase().includes(searchTerm.toLowerCase())
  )

  const handleFile = (file: File) => {
    if (!file.type.startsWith('image/')) return
    setCurrentFile(file)
    setFileName(file.name)
    const reader = new FileReader()
    reader.onload = (e) => {
      setPreviewUrl(e.target?.result as string)
    }
    reader.readAsDataURL(file)
  }

  const handleSave = async () => {
    if (!currentFile || !previewUrl) return
    const name = pictureName.trim() || fileName
    createPicture.mutate({
      name,
      dataUrl: previewUrl,
      fileType: currentFile.type,
      fileSize: currentFile.size,
      isPublic,
    })
    setShowModal(false)
    setPreviewUrl('')
    setFileName('')
    setPictureName('')
    setCurrentFile(null)
    setIsPublic(true)
  }

  const handleDelete = (id: number) => {
    if (confirm('Are you sure you want to delete this picture?')) {
      deletePicture.mutate({ id })
    }
  }

  const handleDownload = (pic: { name: string; dataUrl: string }) => {
    const a = document.createElement('a')
    a.href = pic.dataUrl
    a.download = pic.name
    a.click()
  }

  return (
    <div className="animate-[fadeIn_0.4s_ease]">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 pb-4" style={{ borderBottom: '1px solid var(--border-glass)' }}>
        <h2 className="text-xl font-bold flex items-center gap-3">
          <Images size={24} style={{ color: 'var(--accent-purple)' }} />
          Picture Database
        </h2>
        <button onClick={() => setShowModal(true)} className="btn-primary">
          <CloudUpload size={16} /> Upload Picture
        </button>
      </div>

      {/* Search */}
      <div className="mb-6">
        <div className="relative">
          <Images size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2" style={{ color: 'var(--text-muted)' }} />
          <input type="text" placeholder="Search by name..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} className="form-input pl-10" />
        </div>
      </div>

      {/* Gallery */}
      {isLoading ? (
        <div className="text-center py-16" style={{ color: 'var(--text-muted)' }}>
          <Images size={32} className="mx-auto mb-3 animate-spin" style={{ color: 'var(--accent-purple)' }} />
          <p>Loading pictures...</p>
        </div>
      ) : !filtered || filtered.length === 0 ? (
        <div className="text-center py-16" style={{ color: 'var(--text-muted)' }}>
          <Images size={48} className="mx-auto mb-4 opacity-50" />
          <h4 className="text-base font-semibold mb-1" style={{ color: 'var(--text-secondary)' }}>No pictures found</h4>
          <p className="text-sm">Upload pictures to see them here</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
          {filtered.map((pic) => (
            <div
              key={pic.id}
              className="rounded-2xl overflow-hidden group"
              style={{
                background: 'var(--bg-card)',
                border: '1px solid var(--border-glass)',
                transition: 'all 0.3s ease',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.borderColor = 'var(--border-glass-hover)'
                e.currentTarget.style.transform = 'translateY(-4px)'
                e.currentTarget.style.boxShadow = '0 8px 40px rgba(0,0,0,0.5)'
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.borderColor = 'var(--border-glass)'
                e.currentTarget.style.transform = 'translateY(0)'
                e.currentTarget.style.boxShadow = 'none'
              }}
            >
              <div className="relative overflow-hidden" style={{ height: '200px' }}>
                <img src={pic.dataUrl} alt={pic.name} className="w-full h-full object-cover" loading="lazy" />
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity" style={{ background: 'rgba(0,0,0,0.5)' }}>
                  <button
                    onClick={() => setViewImage(pic.dataUrl)}
                    className="w-12 h-12 rounded-full border-2 border-white flex items-center justify-center text-white hover:bg-white hover:text-black transition-colors"
                  >
                    <Eye size={20} />
                  </button>
                </div>
                {!pic.isPublic && (
                  <span className="absolute top-2 right-2 text-[0.65rem] font-bold px-2 py-0.5 rounded-lg text-white" style={{ background: 'rgba(239, 68, 68, 0.9)' }}>
                    Private
                  </span>
                )}
                {pic.isPublic && (
                  <span className="absolute top-2 right-2 text-[0.65rem] font-bold px-2 py-0.5 rounded-lg text-white" style={{ background: 'rgba(16, 185, 129, 0.9)' }}>
                    Public
                  </span>
                )}
              </div>
              <div className="p-4">
                <h4 className="text-sm font-semibold truncate mb-1">{pic.name}</h4>
                <p className="text-xs mb-3" style={{ color: 'var(--text-muted)' }}>
                  {formatDate(pic.createdAt)}
                </p>
                <div className="flex gap-2">
                  <button onClick={() => handleDownload(pic)} className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-medium text-white transition-colors hover:opacity-90" style={{ background: 'var(--accent-blue)' }}>
                    <Download size={13} /> Download
                  </button>
                  <button onClick={() => handleDelete(pic.id)} className="py-2 px-3 rounded-lg text-xs font-medium transition-colors" style={{ background: 'rgba(239, 68, 68, 0.1)', color: 'var(--accent-red)' }}>
                    <Trash2 size={13} />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Upload Modal */}
      <Dialog open={showModal} onOpenChange={setShowModal}>
        <DialogContent className="glass max-w-lg" style={{ background: 'var(--bg-card)' }}>
          <DialogHeader>
            <DialogTitle className="text-lg font-bold">Upload Picture</DialogTitle>
          </DialogHeader>
          <div className="flex flex-col gap-4 mt-2">
            <div
              className="border-2 border-dashed rounded-2xl p-10 text-center cursor-pointer transition-all"
              style={{
                borderColor: isDragOver ? 'var(--accent-blue)' : 'var(--border-glass)',
                background: isDragOver ? 'rgba(59, 130, 246, 0.05)' : 'var(--bg-glass)',
              }}
              onClick={() => fileInputRef.current?.click()}
              onDragOver={(e) => { e.preventDefault(); setIsDragOver(true) }}
              onDragLeave={() => setIsDragOver(false)}
              onDrop={(e) => { e.preventDefault(); setIsDragOver(false); if (e.dataTransfer.files.length > 0) handleFile(e.dataTransfer.files[0]) }}
            >
              <CloudUpload size={48} style={{ color: 'var(--accent-blue)', marginBottom: '16px' }} />
              <p className="font-medium mb-1">Drop your picture here</p>
              <p className="text-sm" style={{ color: 'var(--text-muted)' }}>or click to browse</p>
              <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={e => { if (e.target.files?.[0]) handleFile(e.target.files[0]) }} />
            </div>

            {previewUrl && (
              <div className="text-center">
                <img src={previewUrl} alt="Preview" className="max-h-[200px] rounded-xl mx-auto" style={{ border: '1px solid var(--border-glass)' }} />
              </div>
            )}

            <div>
              <label className="block mb-2 text-sm font-medium" style={{ color: 'var(--text-secondary)' }}>Name</label>
              <input value={pictureName} onChange={e => setPictureName(e.target.value)} placeholder="Enter name" className="form-input" />
            </div>

            <div className="flex items-center justify-between">
              <label className="text-sm font-medium" style={{ color: 'var(--text-secondary)' }}>Privacy</label>
              <div className="flex items-center gap-3">
                <span className="text-sm" style={{ color: 'var(--text-secondary)' }}>{isPublic ? 'Public' : 'Private'}</span>
                <button
                  type="button"
                  onClick={() => setIsPublic(!isPublic)}
                  className="relative w-12 h-7 rounded-full transition-colors"
                  style={{ background: isPublic ? 'var(--accent-blue)' : 'var(--bg-glass)', border: '1px solid var(--border-glass)' }}
                >
                  <div
                    className="absolute top-1 w-5 h-5 rounded-full bg-white transition-all"
                    style={{ left: isPublic ? '25px' : '3px' }}
                  />
                </button>
              </div>
            </div>

            <div className="flex justify-end gap-3 mt-2">
              <button onClick={() => setShowModal(false)} className="btn-secondary">Cancel</button>
              <button onClick={handleSave} className="btn-primary" disabled={!currentFile}>
                Save Picture
              </button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* View Image Modal */}
      <Dialog open={!!viewImage} onOpenChange={() => setViewImage('')}>
        <DialogContent className="max-w-4xl p-2" style={{ background: 'transparent', border: 'none' }}>
          <img src={viewImage} alt="View" className="w-full rounded-xl" />
        </DialogContent>
      </Dialog>
    </div>
  )
}
