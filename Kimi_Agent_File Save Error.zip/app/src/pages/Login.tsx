import { Shield, LogIn } from 'lucide-react'
import { useAuth } from '@/hooks/useAuth'

function getOAuthUrl() {
  const appid = import.meta.env.VITE_APP_ID
  const authUrl = import.meta.env.VITE_KIMI_AUTH_URL
  const redirectUri = `${window.location.origin}/api/oauth/callback`
  const state = btoa(redirectUri)

  const url = new URL(`${authUrl}/api/oauth/authorize`)
  url.searchParams.set('client_id', appid)
  url.searchParams.set('redirect_uri', redirectUri)
  url.searchParams.set('response_type', 'code')
  url.searchParams.set('scope', 'profile')
  url.searchParams.set('state', state)

  return url.toString()
}

export default function Login() {
  const { isAuthenticated, user, isLoading } = useAuth()

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen" style={{ background: 'var(--bg-primary)' }}>
        <Shield size={48} className="animate-pulse" style={{ color: 'var(--accent-blue)' }} />
      </div>
    )
  }

  if (isAuthenticated && user) {
    return (
      <div className="flex items-center justify-center min-h-screen" style={{ background: 'var(--bg-primary)' }}>
        <div className="card-glass text-center max-w-md w-full mx-4">
          <Shield size={48} className="mx-auto mb-4" style={{ color: 'var(--accent-green)' }} />
          <h2 className="text-xl font-bold mb-2">Already Logged In</h2>
          <p className="text-sm mb-4" style={{ color: 'var(--text-muted)' }}>
            Welcome back, {user.name || 'Developer'}!
          </p>
          <p className="text-sm mb-4" style={{ color: 'var(--text-muted)' }}>
            Role: {user.role === 'admin' ? 'Developer (Admin)' : 'Visitor'}
          </p>
        </div>
      </div>
    )
  }

  return (
    <div className="flex items-center justify-center min-h-screen" style={{ background: 'var(--bg-primary)' }}>
      <div className="card-glass text-center max-w-md w-full mx-4 py-10 px-8">
        <Shield size={56} className="mx-auto mb-5" style={{ color: 'var(--accent-blue)', filter: 'drop-shadow(0 0 20px rgba(59, 130, 246, 0.3))' }} />
        <h2 className="text-xl font-bold mb-2">Developer Access</h2>
        <p className="text-sm mb-8" style={{ color: 'var(--text-muted)' }}>
          Login with your admin account to access the developer dashboard and view all data.
        </p>
        <a
          href={getOAuthUrl()}
          className="btn-primary w-full inline-flex"
        >
          <LogIn size={18} /> Login with Kimi
        </a>
        <p className="text-xs mt-4" style={{ color: 'var(--text-muted)' }}>
          Only admin users can view concerns and developer data.
        </p>
      </div>
    </div>
  )
}
