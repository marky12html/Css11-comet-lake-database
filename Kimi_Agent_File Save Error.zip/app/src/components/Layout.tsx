import { Outlet, Link, useLocation } from 'react-router'
import { useState, useEffect } from 'react'
import { useAuth } from '@/hooks/useAuth'
import {
  Home,
  Cake,
  Images,
  AlertTriangle,
  Shield,
  Menu,
  X,
  LogOut,
  Database,
  Sun,
  Moon,
} from 'lucide-react'

const navLinks = [
  { path: '/', label: 'Home', icon: Home },
  { path: '/birthday', label: 'Birthday Database', icon: Cake },
  { path: '/pictures', label: 'Picture Database', icon: Images },
  { path: '/concerns', label: 'Concern Database', icon: AlertTriangle },
  { path: '/developer', label: 'Developer Access', icon: Shield },
]

export default function Layout() {
  const location = useLocation()
  const { user, isAuthenticated, logout } = useAuth()
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [collapsed, setCollapsed] = useState(false)

  useEffect(() => {
    setSidebarOpen(false)
  }, [location.pathname])

  const isActive = (path: string) => location.pathname === path

  return (
    <div className="flex min-h-screen" style={{ background: 'var(--bg-primary)' }}>
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-[999] lg:hidden"
          style={{ background: 'rgba(0,0,0,0.6)', backdropFilter: 'blur(4px)' }}
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`fixed lg:static z-[1000] flex flex-col h-screen transition-all duration-300 ${
          sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
        style={{
          width: collapsed ? 'var(--sidebar-collapsed)' : 'var(--sidebar-width)',
          background: 'var(--bg-secondary)',
          borderRight: '1px solid var(--border-glass)',
        }}
      >
        {/* Sidebar Header */}
        <div
          className="flex items-center justify-between px-5 py-6"
          style={{ borderBottom: '1px solid var(--border-glass)' }}
        >
          <div className="flex items-center gap-3 font-extrabold text-lg" style={{ color: 'var(--text-primary)' }}>
            <Database size={24} style={{ color: 'var(--accent-blue)' }} />
            {!collapsed && <span>CSS DATABASE</span>}
          </div>
          <button
            onClick={() => setCollapsed(!collapsed)}
            className="hidden lg:block p-2 rounded-lg transition-colors"
            style={{ color: 'var(--text-secondary)' }}
            onMouseEnter={(e) => (e.currentTarget.style.background = 'var(--bg-glass)')}
            onMouseLeave={(e) => (e.currentTarget.style.background = 'transparent')}
          >
            <Menu size={18} />
          </button>
          <button
            onClick={() => setSidebarOpen(false)}
            className="lg:hidden p-2 rounded-lg"
            style={{ color: 'var(--text-secondary)' }}
          >
            <X size={18} />
          </button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 py-4 px-3 flex flex-col gap-1 overflow-y-auto">
          {navLinks.map((link) => {
            const active = isActive(link.path)
            return (
              <Link
                key={link.path}
                to={link.path}
                className={`flex items-center gap-3.5 px-4 py-3.5 rounded-xl font-medium text-[0.95rem] transition-all relative overflow-hidden ${
                  active ? 'text-[#60a5fa]' : ''
                }`}
                style={{
                  color: active ? 'var(--accent-blue-light)' : 'var(--text-secondary)',
                  background: active ? 'rgba(59, 130, 246, 0.1)' : 'transparent',
                }}
                onMouseEnter={(e) => {
                  if (!active) {
                    e.currentTarget.style.color = 'var(--text-primary)'
                    e.currentTarget.style.background = 'var(--bg-glass)'
                  }
                }}
                onMouseLeave={(e) => {
                  if (!active) {
                    e.currentTarget.style.color = 'var(--text-secondary)'
                    e.currentTarget.style.background = 'transparent'
                  }
                }}
              >
                {active && (
                  <div
                    className="absolute left-0 top-0 h-full w-[3px] rounded-r"
                    style={{ background: 'var(--accent-blue)' }}
                  />
                )}
                <link.icon size={20} style={{ width: '24px', textAlign: 'center' }} />
                {!collapsed && <span>{link.label}</span>}
              </Link>
            )
          })}
        </nav>

        {/* Sidebar Footer */}
        <div className="p-4" style={{ borderTop: '1px solid var(--border-glass)' }}>
          <div
            className="flex items-center gap-3 px-3 py-3 rounded-xl mb-3"
            style={{ background: 'var(--bg-glass)' }}
          >
            <div
              className="w-10 h-10 rounded-full flex items-center justify-center text-sm"
              style={{ background: 'var(--accent-blue)' }}
            >
              <Shield size={16} />
            </div>
            {!collapsed && (
              <div className="flex flex-col">
                <span className="font-semibold text-sm">{isAuthenticated && user?.name ? user.name : 'Guest'}</span>
                <span className="text-xs" style={{ color: 'var(--text-muted)' }}>
                  {isAuthenticated && user?.role === 'admin' ? 'Developer' : 'Visitor'}
                </span>
              </div>
            )}
          </div>
          {isAuthenticated && (
            <button
              onClick={logout}
              className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl font-medium text-sm cursor-pointer transition-all"
              style={{
                border: '1px solid var(--border-glass)',
                background: 'transparent',
                color: 'var(--text-secondary)',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.background = 'rgba(239, 68, 68, 0.1)'
                e.currentTarget.style.borderColor = 'var(--accent-red)'
                e.currentTarget.style.color = 'var(--accent-red)'
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = 'transparent'
                e.currentTarget.style.borderColor = 'var(--border-glass)'
                e.currentTarget.style.color = 'var(--text-secondary)'
              }}
            >
              <LogOut size={16} />
              {!collapsed && <span>Logout</span>}
            </button>
          )}
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-h-screen w-full lg:w-auto">
        {/* Top Bar */}
        <header
          className="flex items-center justify-between px-6 lg:px-8 py-5 sticky top-0 z-[100]"
          style={{
            background: 'var(--bg-secondary)',
            borderBottom: '1px solid var(--border-glass)',
          }}
        >
          <button
            onClick={() => setSidebarOpen(true)}
            className="lg:hidden p-2 rounded-lg mr-3"
            style={{ color: 'var(--text-secondary)' }}
          >
            <Menu size={20} />
          </button>
          <div>
            <h1
              className="text-xl lg:text-2xl font-extrabold tracking-tight"
              style={{
                background: 'linear-gradient(135deg, var(--text-primary), var(--accent-blue-light))',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                backgroundClip: 'text',
              }}
            >
              CSS DATABASE LUIS Y FERRER
            </h1>
            <p className="text-xs lg:text-sm mt-0.5" style={{ color: 'var(--text-muted)' }}>
              Comprehensive Student Services Management System
            </p>
          </div>
        </header>

        {/* Page Content */}
        <div className="flex-1 p-4 lg:p-8 overflow-y-auto">
          <Outlet />
        </div>
      </main>
    </div>
  )
}
