// Relations are defined here when needed
// Currently all tables are independent
