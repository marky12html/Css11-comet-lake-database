import {
  mysqlTable,
  mysqlEnum,
  serial,
  varchar,
  text,
  timestamp,
  int,
  boolean,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  unionId: varchar("unionId", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 320 }),
  avatar: text("avatar"),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
  lastSignInAt: timestamp("lastSignInAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const birthdays = mysqlTable("birthdays", {
  id: serial("id").primaryKey(),
  firstName: varchar("first_name", { length: 255 }).notNull(),
  lastName: varchar("last_name", { length: 255 }).notNull(),
  month: int("month").notNull(),
  day: int("day").notNull(),
  birthYear: int("birth_year").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull().$onUpdate(() => new Date()),
});

export type Birthday = typeof birthdays.$inferSelect;
export type InsertBirthday = typeof birthdays.$inferInsert;

export const pictures = mysqlTable("pictures", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  dataUrl: text("data_url").notNull(),
  fileType: varchar("file_type", { length: 100 }),
  fileSize: int("file_size"),
  isPublic: boolean("is_public").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type Picture = typeof pictures.$inferSelect;
export type InsertPicture = typeof pictures.$inferInsert;

export const concerns = mysqlTable("concerns", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  message: text("message").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type Concern = typeof concerns.$inferSelect;
export type InsertConcern = typeof concerns.$inferInsert;

export const activityLogs = mysqlTable("activity_logs", {
  id: serial("id").primaryKey(),
  action: varchar("action", { length: 50 }).notNull(),
  module: varchar("module", { length: 50 }).notNull(),
  details: text("details"),
  userName: varchar("user_name", { length: 255 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type ActivityLog = typeof activityLogs.$inferSelect;
export type InsertActivityLog = typeof activityLogs.$inferInsert;

export const wipeLogs = mysqlTable("wipe_logs", {
  id: serial("id").primaryKey(),
  username: varchar("username", { length: 255 }).notNull(),
  status: varchar("status", { length: 50 }).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type WipeLog = typeof wipeLogs.$inferSelect;
export type InsertWipeLog = typeof wipeLogs.$inferInsert;
